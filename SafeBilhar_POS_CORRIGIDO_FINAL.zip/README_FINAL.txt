# Safe Bilhar POS — Versão Final Corrigida

Correções desta versão:
- Transferência de produtos de loja para loja corrigida.
- Ao transferir, baixa stock da loja origem e aumenta na loja destino.
- Se o produto ainda não existir na loja destino, o sistema cria automaticamente.
- Produtos agora permitem adicionar novo e editar com validação.
- Configurações agora têm mais opções: empresa, NIF, telefone, endereço, moeda, mensagem do recibo, alerta de stock, desconto máximo, IVA, impressora e venda sem stock.
- Usuário perfil Caixa fica limitado a: PDV/caixa, ver stock, abertura e fecho de caixa.
- Administrador e Proprietário continuam com acesso completo.
- Caixa agora tem abertura e fecho.

Logins padrão:
- Proprietário: admin / 1234
- Caixa: caixa / 1234

Publicação:
1. Envie todos os arquivos para o GitHub.
2. Ligue o repositório ao Netlify.
3. Configure Supabase se quiser usar banco online.
4. O sistema também funciona em modo local se o Supabase falhar.
